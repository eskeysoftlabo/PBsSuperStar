local P = PBsSuperStar

function P:Open()
    SCENE_MANAGER:Push(self.sceneName)
end

function P:InstallMenu()
    if self.menuInstalled or not ZO_MENU_ENTRIES then return end
    for _, entry in ipairs(ZO_MENU_ENTRIES) do
        if entry.data and entry.data.scene == self.sceneName then self.menuInstalled = true; return end
    end
    local name = "ステータス超詳細"
    local icon = "EsoUI/Art/MenuBar/Gamepad/gp_playerMenu_icon_character.dds"
    local entry = ZO_GamepadEntryData:New(name, icon)
    entry:SetIconTintOnSelection(true)
    entry:SetIconDisabledTintOnSelection(true)
    entry:SetEnabled(true)
    entry.id = self.name -- String key avoids colliding with built-in numeric category IDs.
    entry.data = {name = name, icon = icon, scene = self.sceneName}
    table.insert(ZO_MENU_ENTRIES, entry)
    self.menuInstalled = true
end

function P:Initialize()
    local U = self.UI
    U:Create()
    self.scene = ZO_Scene:New(self.sceneName, SCENE_MANAGER)
    self.scene:AddFragmentGroup(FRAGMENT_GROUP.GAMEPAD_DRIVEN_UI_WINDOW)
    self.scene:AddFragment(ZO_FadeSceneFragment:New(U.root))
    local binds = U:Keybinds()
    self.scene:RegisterCallback("StateChange", function(_, state)
        if state == SCENE_SHOWING then
            U:Resize()
            U:Refresh()
            KEYBIND_STRIP:AddKeybindButtonGroup(binds)
            -- Poll only while visible: covers stats, buffs, equipment, CP and bar swaps.
            EVENT_MANAGER:RegisterForUpdate(self.name .. "Refresh", 1500, function() U:Refresh() end)
        elseif state == SCENE_HIDING then
            EVENT_MANAGER:UnregisterForUpdate(self.name .. "Refresh")
            KEYBIND_STRIP:RemoveKeybindButtonGroup(binds)
        end
    end)
    self:InstallMenu()
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_PLAYER_ACTIVATED, function() self:InstallMenu() end)
    EVENT_MANAGER:RegisterForEvent(self.name, EVENT_SCREEN_RESIZED, function() U:Resize() end)
    -- Development convenience on PC. Console entry point is the gamepad main menu.
    SLASH_COMMANDS["/pbss"] = function() self:Open() end
end

EVENT_MANAGER:RegisterForEvent(P.name, EVENT_ADD_ON_LOADED, function(_, addonName)
    if addonName ~= P.name then return end
    EVENT_MANAGER:UnregisterForEvent(P.name, EVENT_ADD_ON_LOADED)
    P:Initialize()
end)
