local P = PBsSuperStar
P.UI = { column = 1, selected = {1, 1, 1, 1}, offsets = {0, 0, 0, 0}, visibleRows = 16, showAll = false }
local U = P.UI
local W, H, CW, RH = 1800, 960, 426, 34
local GOLD = {0.85, 0.72, 0.43, 1}
local WHITE = {0.9, 0.92, 0.96, 1}
local MUTED = {0.56, 0.63, 0.72, 1}
local function label(parent, x, y, w, h, size)
    local c = WINDOW_MANAGER:CreateControl(nil, parent, CT_LABEL)
    c:SetAnchor(TOPLEFT, parent, TOPLEFT, x, y)
    c:SetDimensions(w, h)
    c:SetFont("$(GAMEPAD_MEDIUM_FONT)|" .. size .. "|soft-shadow-thin")
    c:SetColor(unpack(WHITE))
    return c
end
local function background(parent, x, y, w, h, r, g, b, a)
    local c = WINDOW_MANAGER:CreateControl(nil, parent, CT_BACKDROP)
    c:SetAnchor(TOPLEFT, parent, TOPLEFT, x, y)
    c:SetDimensions(w, h)
    c:SetCenterColor(r, g, b, a)
    c:SetEdgeColor(0, 0, 0, 0)
    return c
end

function U:Resize()
    local width, height = GuiRoot:GetDimensions()
    self.root:SetScale(math.min(width / (W + 100), height / (H + 100)))
end

function U:Create()
    if self.root then return end
    local root = WINDOW_MANAGER:CreateTopLevelWindow("PBsSuperStarWindow")
    self.root = root
    root:SetDimensions(W, H)
    root:SetAnchor(CENTER, GuiRoot, CENTER, 0, -12)
    root:SetHidden(true)
    background(root, 0, 0, W, H, 0.025, 0.037, 0.06, 0.98)
    background(root, 28, 28, 5, 72, unpack(GOLD))
    label(root, 48, 25, 1000, 50, 38):SetText(P.title)
    self.identity = label(root, 48, 78, 1710, 32, 24)
    self.status = label(root, 1080, 35, 680, 35, 22)
    self.status:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    self.columns = {}
    for i, title in ipairs({"装備", "詳細ステータス・効果", "星座・CP", "スキル"}) do
        local x = 30 + (i - 1) * (CW + 12)
        local c = {rows = {}}
        c.back = background(root, x, 134, CW, 610, 0.055, 0.075, 0.105, 1)
        c.title = label(root, x + 14, 144, CW - 28, 36, 25)
        c.title:SetText(title)
        c.count = label(root, x + 14, 714, CW - 28, 26, 19)
        for n = 1, self.visibleRows do
            local y = 182 + (n - 1) * RH
            local r = {}
            r.highlight = background(root, x + 6, y, CW - 12, RH, 0.20, 0.25, 0.31, 1)
            r.icon = WINDOW_MANAGER:CreateControl(nil, root, CT_TEXTURE)
            r.icon:SetAnchor(TOPLEFT, root, TOPLEFT, x + 10, y + 4)
            r.icon:SetDimensions(26, 26)
            r.name = label(root, x + 42, y + 3, CW - 154, RH - 3, 21)
            r.name:SetMaxLineCount(1)
            r.name:SetWrapMode(TEXT_WRAP_MODE_ELLIPSIS)
            r.value = label(root, x + CW - 108, y + 3, 96, RH - 3, 20)
            r.value:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
            c.rows[n] = r
        end
        self.columns[i] = c
    end
    self.detailTitle = label(root, 44, 757, 1710, 34, 24)
    self.detailTitle:SetColor(unpack(GOLD))
    self.detailTitle:SetMaxLineCount(1)
    self.detailTitle:SetWrapMode(TEXT_WRAP_MODE_ELLIPSIS)
    local scroll = WINDOW_MANAGER:CreateControl("PBsSuperStarDetailScroll", root, CT_SCROLL)
    scroll:SetAnchor(TOPLEFT, root, TOPLEFT, 44, 799)
    scroll:SetDimensions(1710, 111)
    self.detailScroll = scroll
    self.detail = label(scroll, 0, 0, 1680, 0, 22)
    self.detail:SetHeight(0)
    label(root, 44, 924, 1710, 26, 18):SetText("十字キー：列・行を移動   L1/R1・LB/RB：前後のページ   L2/R2・LT/RT：説明をスクロール")
    self:Resize()
end

function U:Refresh()
    -- Preserve selection by stable key as buffs and skill lists change.
    local keys = {}
    for i = 1, 4 do
        local old = self.data and self.data[i][self.selected[i]]
        keys[i] = old and old.key
    end
    self.data = P.Data.Collect(self.showAll)
    for i = 1, 4 do
        for n, entry in ipairs(self.data[i]) do
            if entry.key == keys[i] then self.selected[i] = n; break end
        end
        self.selected[i] = math.max(1, math.min(self.selected[i], #self.data[i]))
    end
    self.identity:SetText(P.Data.Identity())
    self.status:SetText(self.showAll and "未取得を含む全項目" or "取得済みのCP・スキル")
    self:Render()
end

function U:Render()
    for i, c in ipairs(self.columns) do
        local entries, selected = self.data[i], self.selected[i]
        local offset = math.min(self.offsets[i], math.max(0, #entries - self.visibleRows))
        if selected <= offset then offset = selected - 1 end
        if selected > offset + self.visibleRows then offset = selected - self.visibleRows end
        self.offsets[i] = offset
        c.title:SetColor(unpack(i == self.column and GOLD or WHITE))
        c.back:SetEdgeColor(unpack(i == self.column and GOLD or {0, 0, 0, 0}))
        for n, r in ipairs(c.rows) do
            local entry = entries[offset + n]
            r.highlight:SetHidden(not entry or i ~= self.column or offset + n ~= selected)
            r.name:SetText(entry and entry.name or "")
            r.name:SetWidth(entry and entry.value ~= "" and CW - 154 or CW - 54)
            r.name:SetColor(unpack(entry and entry.header and GOLD or WHITE))
            r.value:SetText(entry and entry.value or "")
            r.value:SetColor(unpack(MUTED))
            r.icon:SetHidden(not entry or not entry.icon or entry.icon == "")
            if entry and entry.icon and entry.icon ~= "" then r.icon:SetTexture(entry.icon) end
        end
        c.count:SetText(#entries == 0 and "該当項目なし" or string.format("%d / %d    表示 %d–%d", selected, #entries, offset + 1, math.min(offset + self.visibleRows, #entries)))
    end
    local entry = self.data[self.column][self.selected[self.column]]
    local key = self.column .. ":" .. (entry and entry.key or "")
    if key ~= self.detailKey then self.detailScroll:SetVerticalScroll(0); self.detailKey = key end
    self.detailTitle:SetText(entry and (entry.name .. "   " .. entry.value) or "詳細")
    local text = entry and entry.detail or "この列に表示できる情報はありません。"
    -- Avoid resetting the scroll position every polling tick if the text is unchanged.
    if text ~= self.detailText then
        self.detailText = text
        self.detail:SetText(text)
        self.detail:SetHeight(self.detail:GetTextHeight())
    end
end

function U:MoveColumn(delta)
    self.column = (self.column - 1 + delta) % 4 + 1
    self:Render()
end
function U:MoveRow(delta)
    self.selected[self.column] = math.max(1, math.min(#self.data[self.column], self.selected[self.column] + delta))
    self:Render()
end
function U:ScrollDetail(delta)
    local maxScroll = math.max(0, self.detail:GetHeight() - self.detailScroll:GetHeight())
    self.detailScroll:SetVerticalScroll(math.max(0, math.min(maxScroll, self.detailScroll:GetVerticalScroll() + delta)))
end

function U:Keybinds()
    local group = {alignment = KEYBIND_STRIP_ALIGN_LEFT}
    local function bind(key, name, callback, ethereal)
        group[#group + 1] = {keybind = key, name = name, callback = callback, ethereal = ethereal}
    end
    bind("UI_SHORTCUT_NEGATIVE", "戻る", function() SCENE_MANAGER:HideCurrentScene() end)
    bind("UI_SHORTCUT_SECONDARY", "再取得", function() self:Refresh() end)
    bind("UI_SHORTCUT_TERTIARY", "取得済み / 全項目", function() self.showAll = not self.showAll; self:Refresh() end)
    bind("UI_SHORTCUT_INPUT_LEFT", "前の列", function() self:MoveColumn(-1) end, true)
    bind("UI_SHORTCUT_INPUT_RIGHT", "次の列", function() self:MoveColumn(1) end, true)
    bind("UI_SHORTCUT_INPUT_UP", "前の行", function() self:MoveRow(-1) end, true)
    bind("UI_SHORTCUT_INPUT_DOWN", "次の行", function() self:MoveRow(1) end, true)
    bind("UI_SHORTCUT_LEFT_SHOULDER", "前のページ", function() self:MoveRow(-self.visibleRows) end, true)
    bind("UI_SHORTCUT_RIGHT_SHOULDER", "次のページ", function() self:MoveRow(self.visibleRows) end, true)
    bind("UI_SHORTCUT_LEFT_TRIGGER", "説明を上へ", function() self:ScrollDetail(-80) end, true)
    bind("UI_SHORTCUT_RIGHT_TRIGGER", "説明を下へ", function() self:ScrollDetail(80) end, true)
    return group
end
